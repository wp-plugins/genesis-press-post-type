<?php 

?>

<div id="presspost_options">
	<table>
		<tr>
			<td>Source Article: </td><td valign="top"><input type="text" name="sourceName" value="<?php echo $sourceName; ?>" size="40"/></td>
			<td>Source Link: </td>
			<td><input type="text" name="sourceNameLink" value="<?php echo $sourceLink; ?>" size="40"/></td>
		</tr>
		<tr>
			<td>Related Article 1: </td><td valign="top"><input type="text" name="article1" value="<?php echo $articleName1; ?>" size="40"/></td>
			<td>Related Link 1: </td>
			<td><input type="text" name="articleLink1" value="<?php echo $articleLink1; ?>" size="40"/></td>
		</tr>
		<tr>
			<td>Related Article 2: </td><td valign="top"><input type="text" name="article2" value="<?php echo $articleName2; ?>" size="40"/></td>
			<td>Related Link 2: </td>
			<td><input type="text" name="articleLink2" value="<?php echo $articleLink2; ?>" size="40"/></td>
		</tr>
	</table>
</div>